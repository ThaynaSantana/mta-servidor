addEventHandler( "onClientResourceStart", resourceRoot, function( )
	setAmbientSoundEnabled( "general", false );
	setAmbientSoundEnabled( "gunfire", false );
end )