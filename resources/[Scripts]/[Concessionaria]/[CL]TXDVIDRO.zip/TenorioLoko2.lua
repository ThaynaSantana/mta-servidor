function da ( ) 
setFarClipDistance(4000)  
setCloudsEnabled(true) 
end 
setTimer(da, 5000, 0)